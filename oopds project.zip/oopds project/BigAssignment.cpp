

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<fstream>


#define ADMIN_PASSWORD "foo"  //Admin password
#define ADMIN 2
#define TOURIST 1

using namespace std;

/**
*This struct is for handling attraction types, getting type Ids, names for attraction type easily.
*/
struct AttractionType{
	string typeName;
	int typeID;
	bool isPermitted; //Admin may want to delete a specific attraction type from all cities or may readd it. This variable contains the status of that type.
	AttractionType(){}
	AttractionType(string typeName, int typeID, bool isPermitted){
		this->typeName=typeName;
		this->typeID=typeID;
		this->isPermitted=isPermitted;
	}
};

//including My Node
#include "myNode.h"
//including ADT list
#include "MyADTlist.h"
//including ADT stack
#include "MyADTstack.h"
//including MyClasses , contains declaration and definition of City, Attractions classes.
#include "MyClasses.h"


int USER; // USER == ADMIN or USER == TOURIST


LIST <City*> cityList; //contains list of cities, Using LIST of MyADTList.h
LIST<AttractionType*>attractionTypeList; //contains the attraction types

//including fligthHandlingHelper,  deals with flight queries, modification of flights
#include "FlightInfoHandler.h"

/**
*input = Attraction Type Name, e.g. "Sports", "Culture"
*output = (if exists) the type ID of that attraction type, else -1;
*/
int getTypeID(string typeName){
	for(int i=0;i<attractionTypeList.getLength();i++){
		AttractionType *attType=attractionTypeList.getItemAt(i);
		if(attType->typeName==typeName)
			return attType->typeID;
	}
	return -1;
}

/**
*Displays the cities from list of cities in console
*/
void displayCityList(){
	cout<<endl<<"Cities : "<<endl;
	for(int i=0;i<cityList.getLength();i++){
		cout<<i+1<<". "<<cityList.getItemAt(i)->getName()<<endl;
    }
}

/**
*A bubble sort algo to sort cities in the list
*/
void sortCities(){
	int n=cityList.getLength();
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
			City *cityA = cityList.getItemAt(i);
			City *cityB = cityList.getItemAt(j);
			if(cityA->getName()>cityB->getName()){
				cityList.setItem(i,cityB);
				cityList.setItem(j,cityA);
            }
        }
    }
}


/**
*Asks the user to enter city number from the displayed list
* returns the entered number
*/
char chooseACity(){
    //Printing Cities
    displayCityList();

    //getting choice
	cout<<endl<<"Enter The City Number (1-"<<cityList.getLength()<<") You Want To View or, 0 to EXIT : ";
    int choice;
    cin>>choice;
    return choice;
}

/**
*
*/
int chooseAttractionInputType(){
    cout<<"Would You Like To Choose From Attraction Type Or Attraction Itself?"<<endl;
    cout<<"1. Choose by Attraction Type"<<endl;
    cout<<"2. Choose by Attraction Itself"<<endl;
    cout<<endl<<"Enter Choice : ";
    int choice;
    cin>>choice;
    return choice;
}

/**
* Shows the attraction by types or Attraction list in console
*/
void viewAttraction(int cityChoice){
	City city=*cityList.getItemAt(cityChoice);
	cout<<endl<<city.getName()<<endl;
    cout<<"============================="<<endl;

	int lastTypeID=attractionTypeList.getItemAt(attractionTypeList.getLength()-1)->typeID;
    //arranging attractions according to types
    LIST<Attraction*> attractionPtrs=city.getAttractions();
    LIST<LIST<Attraction*> *> attractionPtrsByType;
	attractionPtrsByType.createLIST(lastTypeID+1);//totalTypes possible = LastTypeID


	for(int k=0;k<attractionTypeList.getLength();k++){
		int type=attractionTypeList.getItemAt(k)->typeID;
		attractionPtrsByType.setItem(type,new LIST<Attraction*>());
        for(int i=0;i<attractionPtrs.getLength();i++){
            if(attractionPtrs.getItemAt(i)->getTypeID()==type){
                attractionPtrsByType.getItemAt(type)->addItem(attractionPtrs.getItemAt(i));
            }
        }
    }

    int choice=chooseAttractionInputType();//Deciding if user wants to view by type or attractions directly
    if(choice==1){
        //printing available attraction types
        cout<<endl<<"Available Attraction Types : "<<endl;
        cout<<"---------------------------------------"<<endl;

		for(int k=0;k<attractionTypeList.getLength();k++){
			AttractionType *attType=attractionTypeList.getItemAt(k);
			if(!attType->isPermitted)
				continue;
			cout<<k+1<<". "<<attType->typeName<<endl;
        }
		cout<<"0. Back"<<endl;

        int input;
		cout<<endl<<"Enter Choice (1-"<<attractionTypeList.getLength()<< ") : ";

        cin>>input;
        if(input==0){
            return;
        }
		if(input<=attractionTypeList.getLength()){
			AttractionType *attType=attractionTypeList.getItemAt(input-1);
			cout<<endl<<"Selected Type : "<<attType->typeName<<endl;
			int type=attType->typeID;
			if(attractionPtrsByType.getItemAt(type)->getLength()==0){
				cout<<"Sorry there is no attraction of this type in this city"<<endl;
				return;
            }
            cout<<"Attractions of this type are : "<<endl;
            for(int i=0;i<attractionPtrsByType.getItemAt(type)->getLength();i++){
                cout<<"\t"<<i+1<<"."<<" "<<attractionPtrsByType.getItemAt(type)->getItemAt(i)->getName()<<endl;
            }
            int k;
            cout<<endl<<endl<<"Now Select The Attraction (1-"<<attractionPtrsByType.getItemAt(type)->getLength()<<") or, enter 0 to get back : ";
            cin>>k;
            if(k!=0){
                cout<<"------------------------------"<<endl;
                attractionPtrsByType.getItemAt(type)->getItemAt(k-1)->display();
                cout<<"------------------------------"<<endl<<endl;
            }
            return;
		}else{
			cout<<"Invalid Input"<<endl;
			return;
		}
    }
    else{
        //printing all attractions of that city
		city.printAttractions();
        int input;
        cout<<endl<<"Enter Attraction Number (1-"<<attractionPtrs.getLength()<<")"<<endl;
        cout<<"[or, you may enter 0 to get back to city list] : ";

        cin>>input;
        if(input==0){
            return;
        }
        cout<<"------------------------------"<<endl;
        attractionPtrs.getItemAt(input-1)->display();
        cout<<"------------------------------"<<endl<<endl;

    }
}

/**
*input : city ID
*output : the index of the city in the list
*/
int getCityIndexInList(int cityId){
	for(int i=0;i<cityList.getLength();i++){
		if(cityList.getItemAt(i)->getId()==cityId)
			return i;
	}
	return -1;
}

/**
*Choosing user, admin or tourist
*If user is admin, an inferface for entering through password
*/

int chooseUser(){
	cout<<"Who are you?"<<endl;
	cout<<"1. Tourist"<<endl;
	cout<<"2. Administrator"<<endl;
	cout<<"Enter your identity [1 or 2] : ";

	int choice;
	cin>>choice;
	char trial='y';
	while(choice==2 && trial=='y'){
		cout<<"Enter Password : ";
		string password;
		cin>>password;
		if(password==ADMIN_PASSWORD){
			return ADMIN;
		}
		else{
			getchar(); //eating new line
			cout<<"Wrong password. Want to try again [y/n] : ";
			cin>>trial;
		}
	}
	return TOURIST;
}

/**
*Interface for visiting cities
*/

void visitCities(){
	int cityChoice=chooseACity();

    if(cityChoice==0)
        return;

    viewAttraction(cityChoice-1);
}

/**
*Simple Interface for flight querying
*/

void flightQueries(){
	int n=cityList.getLength();
	displayCityList();
	int originCity, destCity;
	cout<<"Origin City (1-"<<n<<") : ";
	cin>>originCity;
	if(originCity>n){
		cout<<"Not a valid Input"<<endl;
		return;
	}
	cout<<"Destination City (1-"<<n<<") : ";
	cin>>destCity;
	if(destCity>n){
		cout<<"Not a valid Input"<<endl;
		return;
	}
	string s="From "+cityList.getItemAt(originCity-1)->getName()
		+" to "+cityList.getItemAt(destCity-1)->getName()+".";

	if(isDirectlyConnected(originCity-1,destCity-1)){
		cout<<"Yes, Direct Flight Available "<<s<<endl;
	}else if(isConnected(originCity-1,destCity-1)){
		cout<<"No Direct Flight. But Indirect Flight Available "<<s<<endl;
	}else{
		cout<<"Sorry. No Flight Available "<<s<<endl;
	}
}

/**
*Taking options and doing actions accordingly
*/
void chooseTouristOptions(){
	int choice;
	while(1){
		cout<<endl<<"What is your choice ?"<<endl;
		cout<<"---------------------"<<endl;
		cout<<"1. Visit Cities"<<endl;
		cout<<"2. Flight Queries"<<endl;
		cout<<"0. Exit"<<endl;
		cout<<"---------------------"<<endl;
		cout<<"Enter Choice : ";

		cin>>choice;

		switch(choice){
			case 0: return;
			case 1: visitCities();
					break;
			case 2: flightQueries();
					break;
			default:cout<<"Enter a valid choice."<<endl;
					break;
		}
	}
}

/**
*Saving attraction Type to a file
*/
void saveAttractionTypes(ofstream &file){
	int n=attractionTypeList.getLength();
	file<<n<<endl; //Number of attraction is put in file
	for(int i=0;i<n;i++){// then the n data one after another
		AttractionType *attType=attractionTypeList.getItemAt(i);
		file<<attType->typeID<<endl;
		file<<attType->typeName<<endl;
		file<<(attType->isPermitted?1:0)<<endl;
	}
}

/**
* load attraction types from file
*/

void loadAttractionTypes(ifstream &file){
    //Getting how many attraction types written in file
	string line;
	getline(file,line);
	int n=atoi(line.c_str());

	int id;
	string name;
	bool isPermitted;

    //resetting list
	attractionTypeList.clear();

    //Finally getting n data one after another
	for(int i=0;i<n;i++){
		getline(file,line);
		id=atoi(line.c_str());

		getline(file,line);
		name=line;

		getline(file,line);
		isPermitted=(atoi(line.c_str())==1)?true:false;

		attractionTypeList.addItem(new AttractionType(name,id,isPermitted));
	}
}

/**
* saves data to "data.txt"
*/

void saveData(){
	ofstream file("data.txt");
	if(file.is_open()){
		int n=cityList.getLength();
		file<<n<<endl;
		for(int i=0;i<n;i++){
			cityList.getItemAt(i)->printToFile(file);
		}
		saveAttractionTypes(file);
		saveFlightData(file);
		file.close();
		cout<<"Data Saved Successfully."<<endl;
	}else{
		cout<<"Failed to open file"<<endl;
	}
}

/**
*to load data from file "data.txt"
*/
void loadData(){
	ifstream file("data.txt");
	if(file.is_open()){
		string line;
		if(!getline(file,line)){
			cout<<"No Data Found"<<endl;
			return;
		}

		cityList.clear();

		int n=atoi(line.c_str());

		for(int i=0;i<n;i++){
			City  *city=new City();
			city->extractFromFile(file);
			cityList.addItem(city);
		}
		loadAttractionTypes(file);
		loadFlightData(file);
		file.close();
		cout<<"Data Loaded Successfully"<<endl;
	}else{
		cout<<"Failed to open file"<<endl;
	}
}

int chooseAction(){
	cout<<endl<<"Choose an action"<<endl;
	cout<<"---------------------"<<endl;
	cout<<"1. Add"<<endl;
	cout<<"2. Remove"<<endl;
	cout<<"0. Back"<<endl;
	cout<<"---------------------"<<endl;
	cout<<"Enter Choice : ";
	int choice;
	cin>>choice;
	return choice;
}

/**
* For grtting string input with spaces easily from console
*/

string getStringInput(){
	char input[50];
	cin.getline(input,sizeof(input));
	return (string)input;
}

/**
*An interface to edit city data, e.g remove or add
*/
void editCityData(){
	int actionChoice=chooseAction();
	if(actionChoice==0) //Back
		return;
	if(actionChoice==2)//remove city
	{
		displayCityList();

		int n = cityList.getLength();

		cout<<"Enter the city number to remove (1-"<<n<<") : ";
		int choice;
		cin>>choice;
		if(choice>n){
			cout<<"Invalid input"<<endl;
			return;
		}
		if(cityList.removeItem(choice-1)){
			cout<<"City successfully removed"<<endl;
			refreshMapAfterACityDelete(choice-1); //refreshing flight map as a city's been deleted
			displayCityList(); //displaying cities
			cout<<"Done"<<endl;
		}else{
			cout<<"City removing failed"<<endl;
		}
	}
	else if(actionChoice==1){//add city
		int id;
		string name;
		cout<<"Enter City ID : ";
		cin>>id;
		cout<<"Enter City Name : ";
		getchar();
		name=getStringInput();

		City *newCity = new City(id,name);
		cityList.addItem(newCity);
		sortCities();
		//get new city index
		int n=cityList.getLength();
		int i=0;
		for(;i<n;i++){
			if(cityList.getItemAt(i)->getName()==name)
				break;
		}
		refreshMapAfterACityAdd(i);
		displayCityList();
		cout<<"Done"<<endl;
	}

}
/**
Shows attraction types in console
option=1; to view the permitted attractionTypes only
option=2; to view not permitted attractionTypes only
option=other ; all attractionTypes
*/
void showAllAttractionTypes(int option){
	cout<<"-------------------------"<<endl;
	for(int i=0;i<attractionTypeList.getLength();i++){
		AttractionType *attType=attractionTypeList.getItemAt(i);

		if(option==1 && !attType->isPermitted)continue;
		else if(option==2 && attType->isPermitted)continue;

		attType=attractionTypeList.getItemAt(i);
		cout<<"Type Name : "<<attType->typeName<<", Type ID : "<<attType->typeID<<endl;
	}
	cout<<"-------------------------"<<endl;
}

/**
*An interface to edit attraction data
*/
void editAttractionData(){
	int actionChoice=chooseAction();
	if(actionChoice==0) //Back
		return;

	displayCityList();
	int n=cityList.getLength();
	cout<<"Enter the City of the target attraction (1-"<<n<<") : ";
	int choice;
	cin>>choice;
	if(choice>n){
		cout<<"Invalid input"<<endl;
		return;
	}
	City *city=cityList.getItemAt(choice-1);

	if(actionChoice==2){//remove attraction
		city->printAttractions();
		cout<<"Now Select the attraction to delete : ";
		cin>>choice;
		city->removeAttraction(choice-1);
		city->printAttractions();
		cout<<"Done"<<endl;
	}
	else if(actionChoice==1){//add attraction
		int id;
		string name;
		int typeID;
		string address;
		string availableTime;

		cout<<"Enter Attraction ID : "; cin>>id;
		cout<<"Enter Attraction Name : "; getchar(); name=getStringInput();
		showAllAttractionTypes(1);
		cout<<"Enter Attraction type ID (from the options above) : "; cin>>typeID;
		cout<<"Enter Attraction Location Address : "; getchar(); address=getStringInput();
		cout<<"Enter Availabe time of attraction : "; availableTime=getStringInput();

        //Some extra info the user is to enter (fee or malls list or age limit)
        //depends on the attraction type

		int sportsTypeID=getTypeID("Sports");
		int cultureTypeID=getTypeID("Culture");
		int shoppingTypeID=getTypeID("Shopping");
		int sightSeeingTypeID=getTypeID("SightSeeingPlace");
		int museumTypeID=getTypeID("Museum");

		double fee;
		int ageLimit;

		if(typeID==sportsTypeID){
			cout<<"Enter Age Limit : "<<endl;
			cin>>ageLimit;
			Sports *sports
				=new Sports(id,name,sportsTypeID,address,availableTime,ageLimit);
			city->addAttraction(sports);
		}
		else if(typeID==shoppingTypeID){
			Shopping *shopping
				=new Shopping(id,name,shoppingTypeID,address,availableTime);

			int m;
			cout<<"Enter no. of Malls you want to add to this Shopping : ";
			cin>>m;
			getchar();
			for(int i=0;i<m;i++){
				cout<<"Enter Mall "<<i+1<<" (String value) : ";
				shopping->addMall(getStringInput());
			}

			city->addAttraction(shopping);
		}
		else if(typeID==sightSeeingTypeID){
			cout<<"Enter Hotel Fee Per Night : "<<endl;
			cin>>fee;
			SightSeeingPlace *sightSeeingPlace
				=new SightSeeingPlace(id,name,sightSeeingTypeID,address,availableTime,fee);
			city->addAttraction(sightSeeingPlace);
		}
		else if(typeID==cultureTypeID){
			cout<<"Enter Entrance Fee : "<<endl;
			cin>>fee;
			Culture *culture
				=new Culture(id,name,cultureTypeID,address,availableTime,fee);
			city->addAttraction(culture);
		}
		else {//if(typeID==museumTypeID){
			cout<<"Enter Entrance Fee : "<<endl;
			cin>>fee;
			Museum *museum
				=new Museum(id,name,museumTypeID,address,availableTime,fee);
			city->addAttraction(museum);
		}
		city->printAttractions();
		cout<<"Done"<<endl;
	}
}


/**
*An interface to edit attractionType data
*/

void editAttractionTypeData(){
	int actionChoice=chooseAction();
	if(actionChoice==0) //Back
		return;
	if(actionChoice==1){//add
		//show attraction types waiting to be permitted
		showAllAttractionTypes(2);
		int typeID;
		cout<<"Enter Attraction Type ID to add (from the options above) : ";
		cin>>typeID;
		for(int i=0;i<attractionTypeList.getLength();i++){
			AttractionType *attType=attractionTypeList.getItemAt(i);
			if(attType->typeID==typeID){
				attType->isPermitted=true;
				break;
			}
		}
		//show all permitted attraction type
		showAllAttractionTypes(1);
		cout<<"Done"<<endl;
	}
	else if(actionChoice==2){//remove
		//show all permitted attraction type
		showAllAttractionTypes(1);
		int typeID;
		cout<<"Enter Attraction Type ID to remove (from the options above) : ";
		cin>>typeID;
		for(int i=0;i<attractionTypeList.getLength();i++){
			AttractionType *attType=attractionTypeList.getItemAt(i);
			if(attType->typeID==typeID){
				attType->isPermitted=false;
				cout<<"Deleting this type of attraction from all cities..."<<endl;

				for(int j=0;j<cityList.getLength();j++){
					City *c=cityList.getItemAt(j);
					int k=0;
					while(k<c->getAttractions().getLength()){
						if(c->getAttractions().getItemAt(k)->getTypeID()==typeID){
							c->removeAttraction(k);
							k--;
						}
						k++;
					}
				}
				cout<<"Finished Deleting"<<endl;
				break;
			}
		}
		//show all permitted attraction type
		showAllAttractionTypes(1);
		cout<<"Done"<<endl;
	}
	else{
		cout<<"Invalid input"<<endl;
	}
}

/**
*An interface to edit flight route data
*/

void editFlightRouteData(){
	int actionChoice=chooseAction();
	if(actionChoice==0) //Back
		return;

	int n=cityList.getLength();
	displayCityList();
	int originCity, destCity;
	cout<<"Select origin and destination cities for the route"<<endl;
	cout<<"Origin City (1-"<<n<<") : ";
	cin>>originCity;
	if(originCity>n){
		cout<<"Not a valid Input"<<endl;
		return;
	}
	cout<<"Destination City (1-"<<n<<") : ";
	cin>>destCity;
	if(destCity>n){
		cout<<"Not a valid Input"<<endl;
		return;
	}
	flightMapMatrix[originCity-1][destCity-1]=(actionChoice==1)?1:0;
	string s="From "+cityList.getItemAt(originCity-1)->getName()
		+" to "+cityList.getItemAt(destCity-1)->getName()+".";

	cout<<"Flight "<<((actionChoice==1)?"added to ":"removed from ")<<"route "<<s<<endl;
}

/**
* Selecting what the admin wants to do
*/
void chooseAdminOptions(){
	int choice;
	while(1){
		cout<<endl<<"What is your choice ?"<<endl;
		cout<<"---------------------"<<endl;
		cout<<"1. View data"<<endl;
		cout<<"2. Edit data"<<endl;
		cout<<"3. Save data"<<endl;
		cout<<"4. Load data"<<endl;
		cout<<"0. Exit"<<endl;
		cout<<"---------------------"<<endl;
		cout<<"Enter Choice : ";
		cin>>choice;

		switch(choice){
			case 0: return;
			case 1: chooseTouristOptions();
					break;
			case 2: cout<<endl<<"Which data you want to edit?"<<endl;
					cout<<"---------------------"<<endl;
					cout<<"1. City Data"<<endl;
					cout<<"2. Attraction Data"<<endl;
					cout<<"3. Attraction Type"<<endl;
					cout<<"4. Flight Route"<<endl;
					cout<<"0. Back"<<endl;
					cout<<"---------------------"<<endl;
					cout<<"Enter Choice : ";
					cin>>choice;
					switch(choice){
						case 0: break;
						case 1: editCityData();
								break;
						case 2: editAttractionData();
								break;
						case 3: editAttractionTypeData();
								break;
						case 4: editFlightRouteData();
								break;

						default:cout<<"Enter a valid choice."<<endl;
								break;
					}
					break;
			case 3: cout<<"Saving data..."<<endl;
					saveData();
					break;

			case 4: cout<<"Loading data..."<<endl;
					loadData();
					break;

			default:cout<<"Enter a valid choice."<<endl;
					break;
		}
	}
}

int main(){

    //Storing attraction type name in order to display pointed by typeID
	attractionTypeList.addItem(new AttractionType("Sports",1,true));
	attractionTypeList.addItem(new AttractionType("Culture",2,true));
	attractionTypeList.addItem(new AttractionType("Shopping",3,true));
	attractionTypeList.addItem(new AttractionType("SightSeeingPlace",4,true));
	attractionTypeList.addItem(new AttractionType("Museum",5,false));

	//dummy value insertion starts
    //Some default cities
    City cities[]={
        City(1, "Pink City"),
        City(2, "Capital City"),
        City(3, "Ghost City"),
        City(4, "Small City"),
    };

    //some attractions

        //sports
		int sportTypeId=getTypeID("Sports");
        Sports sports[]={
			Sports(1,"Football",sportTypeId,"Central Football Stadium","From 3:00pm",30),
			Sports(2,"Hockey", sportTypeId,"Hockey Stadium","From 9:00pm",40),
			Sports(3,"Table Tennis", sportTypeId,"Tennis Stadium","From 10:00am",50),
			Sports(4,"Basket Ball",sportTypeId,"Basket Ball Stadium","From 4:00pm",45)
        };

        //cultures
		int cultureTypeId=getTypeID("Culture");
        Culture cultures[]={
			Culture(5,"Summer Night",cultureTypeId, "City Theatre","From 07:00pm", 10.0),
			Culture(6,"Circus Night",cultureTypeId, "Hotel Circus","From 8:00pm", 20.0),
			Culture(7,"Weekly Fest",cultureTypeId, "Town Hall","From 7:00am", 5.0),
			Culture(8,"Drama Show",cultureTypeId, "Drama Theatre", "From 06:00pm", 50.0)
        };

        //shopping
		int shoppingTypeId=getTypeID("Shopping");
        Shopping shoppings[]={
			Shopping(9, "Easy Shopping", shoppingTypeId, "Business Street","24 hours"),
			Shopping(10, "Cheap Shopping", shoppingTypeId, "City Main Road","From 12:00pm to 9:00pm"),
			Shopping(11, "Happy Shopping", shoppingTypeId, "HS Street","From 7:00am to 12:00am")
        };
            //adding Malls to shoppings[0]
            shoppings[0].addMall("Central Shopping Mall");
            shoppings[0].addMall("Concord Shopping Mall");

            shoppings[1].addMall("Capital Shopping Mall");
            shoppings[1].addMall("Popular Shopping Mall");

            shoppings[2].addMall("Grand Plaza Shopping Mall");
            shoppings[2].addMall("Universal Shopping Mall");

        //sightSeeingPlaces
		int sightSeeingPlaceTypeId=getTypeID("SightSeeingPlace");
        SightSeeingPlace sightSeeingPlaces[]={
			SightSeeingPlace(12,"Sea Beach",sightSeeingPlaceTypeId,"City Sea Shore","from 6:00am to 11:00pm",100.0),
            SightSeeingPlace(13,"Grand Lake",sightSeeingPlaceTypeId,"Lake Park","from 6:00am to 11:00pm",50.0),
            SightSeeingPlace(14,"Green Forest",sightSeeingPlaceTypeId,"Forest Zone","from 6:00am to 11:00pm",500.0)
        };

    //adding attractions to cities
    cities[0].addAttraction(&sports[0]);
    cities[0].addAttraction(&cultures[0]);
    cities[0].addAttraction(&shoppings[0]);
    cities[0].addAttraction(&sightSeeingPlaces[0]);

    cities[1].addAttraction(&sports[1]);
    cities[1].addAttraction(&cultures[1]);
    cities[1].addAttraction(&shoppings[1]);
    cities[1].addAttraction(&sightSeeingPlaces[1]);

    cities[2].addAttraction(&sports[2]);
    cities[2].addAttraction(&cultures[2]);
    cities[2].addAttraction(&shoppings[2]);

    cities[3].addAttraction(&sports[3]);
    cities[3].addAttraction(&cultures[3]);
    cities[3].addAttraction(&sightSeeingPlaces[2]);

	for(int i=0;i<4;i++)
		cityList.addItem(&cities[i]);


	//dummy value insertion finished




    //Displaying

    //sorting Cities to alphabetic order
    sortCities();

	//generate dummy flight map
	if(initializeFlightMapMatrix()){
		//add dummy direct flights
		setDirectFlight(0,1);
		setDirectFlight(1,3);
		setDirectFlight(2,3);
		setDirectFlight(0,2);
		setDirectFlight(3,1);
		setDirectFlight(1,2);
		/*
		displayCityList();
		showFlightMapMatrix(4);
		cout<<isConnected(0,1)<<endl;
		cout<<isConnected(1,3)<<endl;
		cout<<isConnected(0,3)<<endl;
		cout<<isConnected(2,1)<<endl;
		/*
		cityList.removeItem(cityList.getItemAt(1));
		displayCityList();
		refreshMapAfterACityDelete(1);
		showFlightMapMatrix(4);

		cityList.addItem(cities[2]);
		sortCities();
		displayCityList();
		refreshMapAfterACityAdd(1);
		showFlightMapMatrix(4);*/
	}else{
		cout<<"FlightMapMatrix Initialization Failed"<<endl;
	}

	USER=chooseUser();
	if(USER==ADMIN){
		cout<<"Welcome Admin"<<endl;
		chooseAdminOptions();
	}else{
		cout<<"Welcome Tourist"<<endl;
		chooseTouristOptions();
	}

    return 0;
}

#include<iostream>
using namespace std;

//ADT list using linked list
template<class item_type>
class LIST{
private:
    Node <item_type> *head; //link head pointer
    int length; //the length of the list
public:
    LIST <item_type> ();
	LIST <item_type> (const LIST <item_type> &obj); //copy constructor
    void createLIST();
    void createLIST(int dummylength);
	bool isEmpty();
    void addItem(item_type item);
    item_type getItemAt(int index);
	void setItem(int index, item_type item);
    int getLength();
    void removeItem(item_type item);
	bool removeItem(int index);
	void clear();
} ;





template<class item_type>
LIST <item_type> :: LIST(){
    createLIST();
}

/**
*Copy constructor
*/
template<class item_type>
LIST <item_type> :: LIST(const LIST <item_type> &obj){
    this->head=new Node <item_type> ();
    head=obj.head;
    this->length=obj.length;
}

template<class item_type>
void LIST <item_type> :: createLIST(){
    this->head=NULL;
    this->length=0;
}

/**
*Creates a dummy list of given length
*/
template<class item_type>
void LIST <item_type> :: createLIST(int dummylength){
    this->head=new Node <item_type> ();
    this->length=0;

    Node <item_type> *tempNode = this->head;
    while(length<dummylength-1){
        tempNode->nextNode=new Node <item_type> ();
        tempNode=tempNode->nextNode;

        this->length++;
    }
    tempNode->nextNode=NULL;
}

template<class item_type>
void LIST <item_type> :: addItem(item_type item){
    if(this->head==NULL){ //LIST hasn't been created yet
        this->head=new Node <item_type> (item);
		this->length=1;
    }
	else{
		Node <item_type> *tempNode = this->head;
		while(tempNode->nextNode!=NULL){
			tempNode=tempNode->nextNode;
		}
		//here, tempNode->nextNode = NULL
		//assigning a new node
		Node <item_type> *newNode = new Node <item_type> (item);
		tempNode->nextNode=newNode;

		//incrementing length
		this->length++;
	}
}


template<class item_type>
item_type LIST <item_type> :: getItemAt(int index){
    Node <item_type> *tempNode = this->head;
    int k=0;//logical index of pointed by head
    while(k<index){
        /*if(tempNode==NULL)//index out of bound
            return (item_type)NULL;*/
        tempNode=tempNode->nextNode;
        k++;
    }
    //here, k=index
    return tempNode->item;
}

template<class item_type>
void LIST <item_type> :: setItem(int index, item_type item){
    Node <item_type> *tempNode = this->head;
    int k=0;//logical index of pointed by head
    while(k<index){
        /*if(tempNode==NULL)//index out of bound
            return (item_type)NULL;*/
        tempNode=tempNode->nextNode;
        k++;
    }
    //here, k=index
    tempNode->item=item;
}

template<class item_type>
int LIST <item_type> :: getLength(){
    if(this->head==NULL){ //LIST hasn't been created yet
        createLIST();
    }

    return this->length;
}

template<class item_type>
bool LIST <item_type> :: isEmpty(){
	if(this->length==0)
		return true;
	return false;
}

template<class item_type>
void LIST <item_type> :: removeItem(item_type item){
	//removes first occurance of item in the list
	if (this->isEmpty())
		return;

    Node <item_type> *tempNode = this->head;

	if(head->item==item){
		head=head->nextNode;
		//delete(tempNode);
	}
	else{
		while(tempNode->nextNode->item!=item){
			tempNode=tempNode->nextNode;
			if(tempNode==NULL) //item not found
				return;
		}
		//here, tempNode->nextNode.item = item
		//saving node to be freed
		Node <item_type> *nodeToFree= tempNode->nextNode;
		//by passing pointer
		tempNode->nextNode=tempNode->nextNode->nextNode;
		//freeing nodeToFree
		//delete(nodeToFree);
	}
	//decrementing length
	this->length--;
}

template<class item_type>
bool LIST <item_type> :: removeItem(int index){
	if (this->isEmpty())
		return false;

    Node <item_type> *tempNode = this->head;

	if(index==0){
		head=head->nextNode;
		//delete(tempNode);
	}
	else{
		int k=0;
		while(k++<index-1){
			tempNode=tempNode->nextNode;
			if(tempNode==NULL) //item not found
				return false;
		}
		//here, k = index
		//saving node to be freed
		Node <item_type> *nodeToFree= tempNode->nextNode;
		//by passing pointer
		tempNode->nextNode=tempNode->nextNode->nextNode;
		//freeing nodeToFree
		//delete(nodeToFree);
	}
	//decrementing length
	this->length--;
	return true;
}


template<class item_type>
void LIST <item_type> :: clear(){
	createLIST();
}

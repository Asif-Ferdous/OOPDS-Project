int **flightMapMatrix; //a 2D dynamic matrix to store flight map

/**
*Set direct flights from fromCityIndex to toCityIndex
*/
void setDirectFlight(int fromCityIndex, int toCityIndex){
	if(cityList.isEmpty())
		return;

	int n = cityList.getLength();

	if(fromCityIndex>=n || toCityIndex>=n)
		return;

	flightMapMatrix[fromCityIndex][toCityIndex]=1;
	//flightMapMatrix[toCityIndex][fromCityIndex]=1;
}

/**
*Initializes the matrix
*/
bool initializeFlightMapMatrix(){
	if(cityList.isEmpty())
		return false;

	int n = cityList.getLength();
	flightMapMatrix=new int*[n];

	for(int i=0;i<n;i++){
		flightMapMatrix[i]=new int[n];
	}

	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			flightMapMatrix[i][j]=0;

	return true;
}

/**
*to refresh the 2D dynamic matrix if a city is deleted
*/
void refreshMapAfterACityDelete(int deletedCityIndex){
	int n=cityList.getLength();
	if(n==0){//there was one city, and now has been deleted
		delete flightMapMatrix[0];
		return;
	}
	//current matrix size = (n+1) X (n+1)
	n++;//current matrix size = n X n

	//shifting row values upward
	for(int i=deletedCityIndex;i<n-1;i++){
		for(int j=0;j<n;j++){
			flightMapMatrix[i][j]=flightMapMatrix[i+1][j];
		}
	}
	//deleting the last row
	delete[] flightMapMatrix[n-1];

	//shifting column values to the left
	for(int j=deletedCityIndex;j<n-1;j++){
		for(int i=0;i<n;i++){
			flightMapMatrix[i][j]=flightMapMatrix[i][j+1];
		}
	}
}

/**
*to refresh the 2D dynamic matrix if a city is added
*/
void refreshMapAfterACityAdd(int addedCityIndex){
	int n=cityList.getLength();
	if(n==1){//there was no city, and now 1
		initializeFlightMapMatrix();
	}
	//current matrix size = (n-1) X (n-1)
	n--;

	//copying the previous matrix
	int **copyMatrix;
	copyMatrix=new int*[n];
	for(int i=0;i<n;i++){
		copyMatrix[i]=new int[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			copyMatrix[i][j]=flightMapMatrix[i][j];
	//copying done

	//reshaping flightMapMatrix
	for(int i=0;i<n;i++){
		delete[] flightMapMatrix[i];
	}
	delete flightMapMatrix;

	initializeFlightMapMatrix();
	//reshaping completed

	//current matrix size = (n+1) X (n+1)
	n++;

	//replacing values from copy
	int p,q;//to avoid the new city
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-1;j++){

			p=i<addedCityIndex?0:1;
			q=j<addedCityIndex?0:1;

			flightMapMatrix[i+p][j+q]=copyMatrix[i][j];
		}
	}
}

/**
*Shows the 2D matrix in console
*/
void showFlightMapMatrix(int dimension){
	cout<<"City Flight Map"<<endl;
	for(int i=0;i<dimension;i++){
		for(int j=0;j<dimension;j++){
			cout<<flightMapMatrix[i][j]<<" ";
		}
		cout<<endl;
	}
}

bool isDirectlyConnected(int fromCityIndex, int destCityIndex){
	return flightMapMatrix[fromCityIndex][destCityIndex]==1?true:false;
}


bool isConnected(int fromCityIndex, int destCityIndex){
	//DFS

	int n=cityList.getLength();
	bool *visited=new bool[n];
	for(int i=0;i<n;i++)
		visited[i]=false;

	STACK <int> aStack;
	aStack.push(fromCityIndex);
	visited[fromCityIndex]=true;

	int topCityIndex=aStack.peek();

	while(!aStack.isEmpty()){
		for(int i=0;i<n;i++){

			if(i==topCityIndex)
				continue;

			if(flightMapMatrix[topCityIndex][i] && !visited[i]){
				aStack.push(i);
				visited[i]=true;
				if(i==destCityIndex)
					return true;
			}
		}
		aStack.pop();
		if(!aStack.isEmpty()){
			topCityIndex=aStack.peek();
		}
	}

	return false;
}

/**
*Saves flight data to file
*/
void saveFlightData(ofstream &file){
	int n=cityList.getLength();
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			file<<flightMapMatrix[i][j]<<endl;
		}
	}
}

/**
*load flight data to file
*/
void loadFlightData(ifstream &file){
	int n=cityList.getLength();
	initializeFlightMapMatrix();
	string line;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			getline(file,line);
			flightMapMatrix[i][j]=atoi(line.c_str());
		}
	}
}

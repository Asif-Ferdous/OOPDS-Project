#include<iostream>
using namespace std;


//STACK using linked list
template<class item_type>
class STACK{
private:
    Node <item_type> *top;
public:
    STACK <item_type> ();
	bool isEmpty();
    bool push(item_type item);
    bool pop();
	item_type peek();
};



template<class item_type>
STACK <item_type> ::STACK(){
    this->top=NULL;
}


template<class item_type>
bool STACK <item_type> ::isEmpty(){
	if(top==NULL)
		return true;
	return false;
}


template<class item_type>
bool STACK <item_type> ::push(item_type item){
    //assigning a new node
    Node <item_type> *newNode = new Node <item_type> (item);

	if(!this->isEmpty()){
		newNode->nextNode=top;
	}

	top=newNode;
	return true;
}

template<class item_type>
bool STACK <item_type> ::pop(){
    if(this->isEmpty())//empty stack
        return false;

    Node <item_type> *nodeToBeFreed = this->top;
    //bypassing
    top=top->nextNode;

    //deleting node from memory
    free(nodeToBeFreed);

	return true;
}

/**
*Get the top item of the stack
*/
template<class item_type>
item_type STACK <item_type> ::peek(){
	return top->item;
}

class City;
class Attraction;
class Sports;
class Culture;
class Shopping;
class SightSeeingPlace;

int getTypeID(string typeName);
//City
class City{
private:
    int id;
    string name;
    LIST<Attraction*>attractions;
public:
	City(){}
    City(int id, string name){
        this->id=id;
        this->name=name;
    }

    int getId(){
        return this->id;
    }
    string getName(){
        return this->name;
    }

    void addAttraction(Attraction* attraction){
        this->attractions.addItem(attraction);
    }

	void removeAttraction(int index){
		this->attractions.removeItem(index);
	}

    LIST <Attraction*> getAttractions(){
        return attractions;
    }
	void setId(int id){
		this->id=id;
	}
	void setName(string name){
		this->name=name;
	}

	void printToFile(ofstream &file);
	void extractFromFile(ifstream &file);
	void printAttractions();
};

//Attraction
///This is an abstract class
class Attraction{
protected:
    int id;
    string name;
    int typeID;
    string address;
    string availableTime;
public:
	Attraction(){}
    Attraction(int id,string name, int typeID, string address, string availableTime){
        this->id=id;
        this->name=name;
        this->typeID=typeID;
        this->address=address;
        this->availableTime=availableTime;
    }

    int getId(){
        return this->id;
    }
    int getTypeID(){
        return this->typeID;
    }

    string getName(){
        return this->name;
    }

	string getAddress(){
		return this->address;
	}

	string getAvailableTime(){
		return this->availableTime;
	}

    virtual void display()=0;
};

//Sports
class Sports: public Attraction{
private:
    int ageLimit;
public:
	Sports(){}
    Sports(int id, string name, int typeID, string address, string availableTime, int ageLimit):Attraction(id,name,typeID, address, availableTime){
        this->ageLimit=ageLimit;
    }

    int getAgeLimit(){
        return this->ageLimit;
    }

    void display(){
        cout<<"ID : "<<this->id<<endl;
        cout<<"Name : "<<this->name<<endl;
        cout<<"Type ID : "<<this->typeID<<endl;
        cout<<"Age Limit : "<<this->ageLimit<<" year "<<endl;
        cout<<"Address : "<<this->address<<endl;
        cout<<"Available : "<<this->availableTime<<endl;
    }
};


//Culture
class Culture: public Attraction{
private:
    double entranceFee;
public:
	Culture(){}
    Culture(int id, string name, int typeID, string address, string availableTime, double entranceFee):Attraction(id,name,typeID, address, availableTime){
        this->entranceFee=entranceFee;
    }

    double getEntranceFee(){
        return this->entranceFee;
    }

    void display(){
        cout<<"ID : "<<this->id<<endl;
        cout<<"Name : "<<this->name<<endl;
        cout<<"Type ID : "<<this->typeID<<endl;
        cout<<"Entrance Fee : "<<this->entranceFee<<" $ "<<endl;
        cout<<"Address : "<<this->address<<endl;
        cout<<"Available : "<<this->availableTime<<endl;
    }
};


//Museum
class Museum: public Attraction{
private:
    double entranceFee;
public:
	Museum(){}
    Museum(int id, string name, int typeID, string address, string availableTime, double entranceFee):Attraction(id,name,typeID, address, availableTime){
        this->entranceFee=entranceFee;
    }

    double getEntranceFee(){
        return this->entranceFee;
    }

    void display(){
        cout<<"ID : "<<this->id<<endl;
        cout<<"Name : "<<this->name<<endl;
        cout<<"Type ID : "<<this->typeID<<endl;
        cout<<"Entrance Fee : "<<this->entranceFee<<" $ "<<endl;
        cout<<"Address : "<<this->address<<endl;
        cout<<"Available : "<<this->availableTime<<endl;
    }
};

//Shopping
class Shopping: public Attraction{
private:
    LIST<string>Malls;
public:
	Shopping(){}
    Shopping(int id, string name, int typeID, string address, string availableTime):Attraction(id,name,typeID, address, availableTime){
        this->Malls.createLIST();
    }

    void addMall(string Mall){
        this->Malls.addItem(Mall);
    }

	LIST<string> getMalls(){
		return this->Malls;
	}

    void display(){
        cout<<"ID : "<<this->id<<endl;
        cout<<"Name : "<<this->name<<endl;
        cout<<"Type ID : "<<this->typeID<<endl;
        cout<<"Address : "<<this->address<<endl;
        cout<<"Available : "<<this->availableTime<<endl;
        cout<<"Malls : "<<endl;
        for(int i=0;i<Malls.getLength();i++){
            char c=97+i;
            cout<<"\t"<<c<<". "<<Malls.getItemAt(i)<<endl;
        }
    }
};


//SightSeeingPlace
class SightSeeingPlace: public Attraction{
    double hotelFeePerNight;
public:
	SightSeeingPlace(){}
    SightSeeingPlace(int id, string name, int typeID, string address, string availableTime, double hotelFeePerNight):Attraction(id,name,typeID, address, availableTime){
        this->hotelFeePerNight=hotelFeePerNight;
    }
	double getHolelFeePerNight(){
		return this->hotelFeePerNight;
	}
    void display(){
        cout<<"ID : "<<this->id<<endl;
        cout<<"Name : "<<this->name<<endl;
        cout<<"Type ID : "<<this->typeID<<endl;
        cout<<"Hotel Fee Per Night : "<<this->hotelFeePerNight<<" $ "<<endl;
        cout<<"Address : "<<this->address<<endl;
        cout<<"Available : "<<this->availableTime<<endl;
    }
};

/**
*Prints all vailable attractions in the city
*/
void City::printAttractions(){
	cout<<endl<<"Available Attractions of "<<name<<" : "<<endl;
    cout<<"---------------------------------------"<<endl;
    for(int i=0;i<attractions.getLength();i++){
		cout<<i+1<<"."<<" "<<attractions.getItemAt(i)->getName()<<endl;
    }
}

/**
*Extract city data from file
*/
void City::extractFromFile(ifstream &file){
	
	string line;
	getline(file,line);
	this->setId(atoi(line.c_str()));
	
	getline(file,line);
	this->setName(line);
	/*
	char input[50];
	getchar();
	is.getline(input,sizeof(input));	
	name=input;*/
	
	getline(file,line);
	int totalAttractions=atoi(line.c_str());
	
	int id;
    string name;
    int typeID;
    string address;
    string availableTime;

	for(int i=0;i<totalAttractions;i++){
		getline(file,line);
		id=atoi(line.c_str());

		getline(file,line);
		name=line;

		getline(file,line);
		typeID=atoi(line.c_str());

		getline(file,line);
		address=line;

		getline(file,line);
		availableTime=line;
		
		int sportsTypeID=getTypeID("Sports");
		int cultureTypeID=getTypeID("Culture");
		int shoppingTypeID=getTypeID("Shopping");
		int sightSeeingTypeID=getTypeID("SightSeeingPlace");
		int museumTypeID=getTypeID("Museum");

		double fee;
		int ageLimit;

		if(typeID==sportsTypeID){
			getline(file,line);
			ageLimit=atoi(line.c_str());
			Sports *sports
				=new Sports(id,name,sportsTypeID,address,availableTime,ageLimit);
			this->addAttraction(sports);
		}
		else if(typeID==shoppingTypeID){
			Shopping *shopping
				=new Shopping(id,name,shoppingTypeID,address,availableTime);

			getline(file,line);
			int m=atoi(line.c_str());

			for(int i=0;i<m;i++){
				getline(file,line);
				shopping->addMall(line);
			}

			this->addAttraction(shopping);
		}
		else if(typeID==sightSeeingTypeID){
			getline(file,line);
			fee=atof(line.c_str());

			SightSeeingPlace *sightSeeingPlace
				=new SightSeeingPlace(id,name,sightSeeingTypeID,address,availableTime,fee);
			this->addAttraction(sightSeeingPlace);
		}
		else if(typeID==cultureTypeID){
			getline(file,line);
			fee=atof(line.c_str());

			Culture *culture
				=new Culture(id,name,cultureTypeID,address,availableTime,fee);
			this->addAttraction(culture);
		}
		else {//if(typeID==museumTypeID){//museum type or other
			getline(file,line);
			fee=atof(line.c_str());

			Museum *museum
				=new Museum(id,name,museumTypeID,address,availableTime,fee);
			this->addAttraction(museum);
		}
	}
}

/**
*Print city data to file
*/
void City::printToFile(ofstream &file){
	file<<this->getId()<<endl;
	file<<this->getName()<<endl;

	LIST<Attraction*> attractionPtrList = this->getAttractions();

	int n=attractionPtrList.getLength();
	file<<n<<endl;
	
	for(int i=0;i<n;i++){
		Attraction *attraction=attractionPtrList.getItemAt(i);
		file<<attraction->getId()<<endl;
		file<<attraction->getName()<<endl;
		file<<attraction->getTypeID()<<endl;
		file<<attraction->getAddress()<<endl;
		file<<attraction->getAvailableTime()<<endl;

		int sportsTypeID=getTypeID("Sports");
		int cultureTypeID=getTypeID("Culture");
		int shoppingTypeID=getTypeID("Shopping");
		int sightSeeingTypeID=getTypeID("SightSeeingPlace");
		int museumTypeID=getTypeID("Museum");

		int typeID=attraction->getTypeID();
		if(typeID==sportsTypeID){
			file<<((Sports*)attraction)->getAgeLimit()<<endl;
		}
		else if(typeID==shoppingTypeID){
			Shopping *shopping=(Shopping*)attraction;
			LIST<string>Malls=shopping->getMalls();
			
			file<<Malls.getLength()<<endl;

			for(int i=0;i<Malls.getLength();i++){
				file<<Malls.getItemAt(i)<<endl;
			}
		}
		else if(typeID==sightSeeingTypeID){
			file<<((SightSeeingPlace*)attraction)->getHolelFeePerNight()<<endl;
		}
		else if(typeID==cultureTypeID){
			file<<((Culture*)attraction)->getEntranceFee()<<endl;
		}
		else {//if(typeID==museumTypeID){//museum type or other
			file<<((Museum*)attraction)->getEntranceFee()<<endl;
		}
	}
}
template<class item_type>
struct Node{
    item_type item;
    Node* nextNode;

    Node(){
        this->nextNode=NULL;
    }

    Node(item_type item){
        this->item=item;
        this->nextNode=NULL;
    }
};
